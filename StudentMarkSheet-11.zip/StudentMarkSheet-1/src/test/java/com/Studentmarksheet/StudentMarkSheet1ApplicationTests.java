package com.Studentmarksheet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentMarkSheet1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
