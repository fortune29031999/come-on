package com.Studentmarksheet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentMarkSheet1Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentMarkSheet1Application.class, args);
	}

}
