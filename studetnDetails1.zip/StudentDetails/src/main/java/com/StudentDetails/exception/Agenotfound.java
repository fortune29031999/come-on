package com.StudentDetails.exception;

public class Agenotfound extends Exception {
	
public  Agenotfound(String a) {
	super(a);
}
}
